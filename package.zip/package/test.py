import boto3
import requests
import os
import time
from decimal import Decimal
from datetime import datetime

# Initialize DynamoDB resource
dynamodb = boto3.resource('dynamodb')

# Environment variables
source_table_name = os.environ.get('PRICE_TRACKER_DB')
if not source_table_name:
    raise ValueError("Missing env var: PRICE_TRACKER_DB")
source_table = dynamodb.Table(source_table_name)

alerts_table_name = os.environ.get('PRICE_ALERTS_DB')
if not alerts_table_name:
    raise ValueError("Missing env var: PRICE_ALERTS_DB")
alerts_table = dynamodb.Table(alerts_table_name)

api_key = os.environ.get('API_KEY')
if not api_key:
    raise ValueError("Missing env var: API_KEY")

# Fetch current stock price with better error handling
def get_stock_price(symbol):
    # Ensure symbol is uppercase for consistency
    symbol = symbol.upper()
    
    url = f"https://finnhub.io/api/v1/quote?symbol={symbol}&token={api_key}"
    
    try:
        response = requests.get(url, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            current_price = data.get('c')
            
            # Check if we got a valid price (not 0 or None)
            if current_price is not None and current_price > 0:
                return current_price
            else:
                print(f"Invalid price returned for {symbol}: {current_price}")
                return None
        else:
            print(f"API error for {symbol}: Status {response.status_code}, Response: {response.text}")
            return None
            
    except requests.exceptions.RequestException as e:
        print(f"Request error for {symbol}: {str(e)}")
        return None
    except Exception as e:
        print(f"Unexpected error fetching price for {symbol}: {str(e)}")
        return None

# Lambda handler
def lambda_handler(event, context):
    processed_count = 0
    alert_count = 0
    error_count = 0
    
    try:
        response = source_table.scan()
        items = response.get('Items', [])

        while 'LastEvaluatedKey' in response:
            response = source_table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
            items.extend(response.get('Items', []))

        for item in items:
            try:
                email = item.get('email')
                # Handle BOTH field name variations - no standardization needed!
                display_symbol = item.get('display_symbol') or item.get('displaySymbol')
                threshold_price = item.get('price')
                password = item.get('password')

                if not email or not display_symbol or threshold_price is None:
                    print(f"Skipping invalid item: {item}")
                    error_count += 1
                    continue

                # Add a small delay to avoid hitting API rate limits
                time.sleep(0.1)
                
                current_price = get_stock_price(display_symbol)
                if current_price is None:
                    print(f"Could not fetch price for {display_symbol}, skipping...")
                    error_count += 1
                    continue

                processed_count += 1
                
                # Compare prices using Decimal for precision
                if Decimal(str(current_price)) < Decimal(str(threshold_price)):
                    alert = {
                        'EMAIL': email,
                        'DISPLAY_SYMBOL': display_symbol.upper(),
                        'CURRENT_PRICE': str(current_price),
                        'THRESHOLD_PRICE': str(threshold_price),
                        'PASSWORD': password,
                        'DATETIME': datetime.utcnow().isoformat()
                    }
                    alerts_table.put_item(Item=alert)
                    alert_count += 1
                    print(f"Alert saved: {alert}")
                else:
                    print(f"No alert for {display_symbol}: current={current_price}, threshold={threshold_price}")
                    
            except Exception as item_error:
                print(f"Error processing item {item}: {str(item_error)}")
                error_count += 1
                continue

        return {
            'statusCode': 200,
            'body': {
                'message': f'Processing complete',
                'total_items': len(items),
                'processed_successfully': processed_count,
                'alerts_created': alert_count,
                'errors': error_count
            }
        }

    except Exception as e:
        print(f"Lambda error: {e}")
        return {
            'statusCode': 500,
            'body': {
                'error': str(e),
                'processed_count': processed_count,
                'alert_count': alert_count
            }
        }